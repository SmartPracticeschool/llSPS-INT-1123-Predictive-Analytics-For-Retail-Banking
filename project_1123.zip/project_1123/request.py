import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'job':2, 'duration':9})

print(r.json())
