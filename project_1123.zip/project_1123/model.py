# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle

df=pd.read_csv('bank.csv')


#df['Job'].replace(-1,0,inplace=True)

df.replace(-1,0,inplace=True)

X['job']=X['job'].apply(lambda X: convert_to_int(x))

y=df.iloc[:,-1]

from sklearn.preprocessing import OneHotEncoder
oh=OneHotEncoder(categories='auto')
X=oh.fit_transform(X).toarray() 

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=0)

from sklearn.linear_model.logistic import LogisticRegression

cls =LogisticRegression(random_state =0)

lr=cls.fit(X_train, y_train)

pickle.dump(lr,open('model.pkl','wb'))

