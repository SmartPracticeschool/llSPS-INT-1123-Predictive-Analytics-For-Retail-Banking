import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))
from sklearn.preprocessing import OneHotEncoder
oh=pickle.load(open('encoder.pkl','rb'))
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    x_test=[[x for x in request.form.values()]]
    x_test[0][1]=int(x_test[0][1])
    x_test=oh.transform(x_test)
    prediction=model.predict(x_test)
    return render_template('index.html',prediction_text=""+str(prediction[0]))

if __name__=="__main__":
    app.run(debug=True)
